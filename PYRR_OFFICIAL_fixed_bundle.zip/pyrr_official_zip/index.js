"use strict";

// ============================================================
// PYRR OFFICIAL | single-file Discord bot
// Node.js 22 | discord.js v14
// Prefix: P'  | slash commands enabled for selected commands
// Creator: YOW Jhay
// ============================================================

const {
  Client, GatewayIntentBits, Partials, PermissionsBitField, EmbedBuilder,
  ActivityType, REST, Routes, SlashCommandBuilder, ActionRowBuilder,
  ButtonBuilder, ButtonStyle, ChannelType, AuditLogEvent
} = require('discord.js');
const fs = require('node:fs');
const path = require('node:path');

const TOKEN = process.env.DISCORD_TOKEN;
const CLIENT_ID = process.env.CLIENT_ID;
const OWNER_ID = process.env.BOT_OWNER_ID || '';
const PREFIX = "P'";
const TWITCH_URL = 'https://m.twitch.tv/noctis_official01/home';
const BOT_NAME = 'PYRR OFFICIAL';
const CREATOR = 'YOW Jhay';
const DATA_DIR = path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'pyrr-data.json');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildModeration, GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent, GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildInvites],
  partials: [Partials.Channel, Partials.Message, Partials.Reaction]
});

let db = {};
try { db = fs.existsSync(DATA_FILE) ? JSON.parse(fs.readFileSync(DATA_FILE, 'utf8') || '{}') : {}; }
catch (e) { console.error('[PYRR] Data file could not be read; starting with empty data.', e.message); db = {}; }
function saveDb() { try { fs.writeFileSync(DATA_FILE, JSON.stringify(db, null, 2)); } catch (e) { console.error('[PYRR] Save failed:', e.message); } }
function guildData(id) {
  if (!db[id]) db[id] = { prefix: PREFIX, logChannel: null, welcomeChannel: null, leaveChannel: null, autorole: null, mutedRole: null, antinuke: false, antiraid: false, automod: false, warnings: {}, disabled: [], tickets: {}, ticketCategory: null, ticketPanel: null, starboard: null, welcomeText: 'Welcome {user} to {server}!', leaveText: '{user} left {server}.', custom: {}, polls: {}, reminders: {} };
  return db[id];
}
const commandMap = new Map();
const aliases = new Map();
const cooldowns = new Map();
const slashCandidates = new Set();
function register(name, description, category, run, options = {}) {
  name = String(name).toLowerCase().trim();
  if (!/^[a-z0-9_-]+$/.test(name)) throw new Error('Invalid command name: ' + name);
  if (commandMap.has(name)) { console.warn('[PYRR] duplicate command skipped:', name); return false; }
  const command = { name, description: description || 'PYRR utility command.', category: category || 'General', run, aliases: options.aliases || [], admin: !!options.admin, mod: !!options.mod, owner: !!options.owner, cooldown: options.cooldown || 0, slash: options.slash !== false };
  commandMap.set(name, command);
  for (const alias of command.aliases) {
    const key = String(alias).toLowerCase().trim();
    if (!key || key === name || commandMap.has(key) || aliases.has(key)) { if (key) console.warn('[PYRR] duplicate alias skipped:', key); continue; }
    aliases.set(key, name);
  }
  if (command.slash && slashCandidates.size < 80) slashCandidates.add(name);
  return true;
}
function embed(title, description, color = 0x5865F2) {
  const e = new EmbedBuilder().setColor(color).setTitle(String(title).slice(0, 256)).setTimestamp();
  if (description !== undefined && description !== null && String(description)) e.setDescription(String(description).slice(0, 4096));
  return e;
}
const ok = (s) => embed('✅ Done', s, 0x2ECC71);
const fail = (s) => embed('❌ Error', s, 0xED4245);
const info = (s) => embed('ℹ️ PYRR OFFICIAL', s, 0x5865F2);
function safeText(s, max = 1800) { return String(s ?? '').slice(0, max); }
function hasPerm(ctx, permission) { return !!ctx.member?.permissions?.has(permission); }
function isOwner(ctx) { return !!OWNER_ID && ctx.author?.id === OWNER_ID; }
function memberFrom(ctx, token) {
  const mentioned = ctx.message?.mentions?.members?.first();
  if (mentioned) return mentioned;
  const raw = String(token || '').replace(/[<@!>]/g, '');
  if (!/^\d{17,20}$/.test(raw)) return null;
  return ctx.guild?.members?.cache?.get(raw) || null;
}
function channelFrom(ctx, token) {
  const mentioned = ctx.message?.mentions?.channels?.first();
  if (mentioned) return mentioned;
  const raw = String(token || '').replace(/[<#>]/g, '');
  if (!/^\d{17,20}$/.test(raw)) return null;
  return ctx.guild?.channels?.cache?.get(raw) || null;
}
function durationMs(raw) {
  const m = String(raw || '').toLowerCase().match(/^(\d+)(s|m|h|d)$/);
  if (!m) return null;
  const n = Number(m[1]); const mult = { s: 1000, m: 60000, h: 3600000, d: 86400000 }[m[2]];
  const ms = n * mult; return Number.isSafeInteger(ms) && ms > 0 && ms <= 2419200000 ? ms : null;
}
function durationLabel(ms) {
  const units = [['d', 86400000], ['h', 3600000], ['m', 60000], ['s', 1000]]; let rem = ms; const out = [];
  for (const [label, size] of units) { const n = Math.floor(rem / size); if (n) { out.push(`${n}${label}`); rem -= n * size; } }
  return out.join(' ') || '0s';
}
function ctxForMessage(message, args) {
  return { source: message, message, interaction: null, guild: message.guild, channel: message.channel, member: message.member, author: message.author, args,
    reply: async (payload) => message.reply(typeof payload === 'string' ? { content: payload, allowedMentions: { repliedUser: false } } : { ...payload, allowedMentions: payload?.allowedMentions || { repliedUser: false } }) };
}
function ctxForInteraction(interaction, args) {
  const member = interaction.member;
  return { source: interaction, message: null, interaction, guild: interaction.guild, channel: interaction.channel, member, author: interaction.user, args,
    reply: async (payload) => { if (interaction.deferred || interaction.replied) return interaction.followUp(typeof payload === 'string' ? { content: payload, ephemeral: true } : { ...payload, ephemeral: payload?.ephemeral ?? true }); return interaction.reply(typeof payload === 'string' ? { content: payload, ephemeral: true } : { ...payload, ephemeral: payload?.ephemeral ?? true }); } };
}
function requireGuild(ctx) { if (!ctx.guild) { ctx.reply({ content: 'This command can only be used in a server.', ephemeral: true }).catch(() => {}); return false; } return true; }
function addWarning(guildId, userId, reason, moderatorId) {
  const g = guildData(guildId); if (!g.warnings[userId]) g.warnings[userId] = [];
  g.warnings[userId].push({ reason: safeText(reason || 'No reason given', 500), moderatorId, at: Date.now() }); saveDb(); return g.warnings[userId].length;
}
async function sendLog(guild, message) {
  const d = guildData(guild.id); if (!d.logChannel) return;
  const ch = guild.channels.cache.get(d.logChannel); if (!ch || !ch.isTextBased()) return;
  await ch.send({ embeds: [embed('Server Log', message, 0x747F8D)] }).catch(() => {});
}
function formatUser(user) { return `${user.tag || user.username} (${user.id})`; }
function resolveText(ctx) { return ctx.args.join(' ').trim(); }

// ---------- CORE / HELP ----------
register('help', 'Show command categories or a command.', 'Information', async (ctx) => {
  const q = (ctx.args[0] || '').toLowerCase();
  if (q && commandMap.has(q)) { const c = commandMap.get(q); return ctx.reply({ embeds: [embed(`P'${c.name}`, `${c.description}\n**Category:** ${c.category}\n**Usage:** \`${PREFIX}${c.name}\``)] }); }
  const cats = [...new Set([...commandMap.values()].map(c => c.category))].sort();
  const lines = cats.map(cat => `**${cat}** — ${[...commandMap.values()].filter(c => c.category === cat).length} commands`);
  return ctx.reply({ embeds: [embed('PYRR OFFICIAL • Help', `Prefix: \`${PREFIX}\`\nExample: \`${PREFIX}help moderation\`\nSlash commands are also available for selected tools.\n\n${lines.join('\n')}\n\nTotal registered: **${commandMap.size}**`)] });
}, { aliases: ['commands', 'cmds'] });
register('ping', 'Show bot latency.', 'Utility', async ctx => ctx.reply({ embeds: [embed('🏓 Pong!', `Gateway: ${client.ws.ping}ms`)] }), { aliases: ['latency'] });
register('botinfo', 'Show bot information.', 'Information', async ctx => ctx.reply({ embeds: [embed(BOT_NAME, `Creator: **${CREATOR}**\nServers: **${client.guilds.cache.size}**\nCommands: **${commandMap.size}**\nLibrary: discord.js v14\nPrefix: \`${PREFIX}\``)] }), { aliases: ['about', 'stats'] });
register('uptime', 'Show how long the bot has been online.', 'Utility', async ctx => ctx.reply({ embeds: [embed('⏱️ Uptime', durationLabel(client.uptime || 0))] }));
register('invite', 'Show the bot invite link.', 'Information', async ctx => ctx.reply({ embeds: [embed('Invite PYRR OFFICIAL', `Use this link to invite the bot:\nhttps://discord.com/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`)] }));
register('support', 'Show support information.', 'Information', async ctx => ctx.reply({ embeds: [embed('PYRR Support', `Creator: ${CREATOR}\nTwitch: ${TWITCH_URL}\nFor help, contact the server administrator who invited this bot.`)] }));
register('prefix', 'Show the bot prefix.', 'Configuration', async ctx => ctx.reply({ embeds: [info(`Current prefix: \`${PREFIX}\`\nThis build uses a fixed prefix.`)] }), { aliases: ['setprefix'] });
register('serverinfo', 'Show server information.', 'Information', async ctx => { if (!requireGuild(ctx)) return; const g = ctx.guild; return ctx.reply({ embeds: [embed(g.name, `ID: ${g.id}\nOwner: <@${g.ownerId}>\nMembers: ${g.memberCount}\nChannels: ${g.channels.cache.size}\nRoles: ${g.roles.cache.size}\nCreated: <t:${Math.floor(g.createdTimestamp / 1000)}:F>`)] }); }, { aliases: ['guildinfo'] });
register('userinfo', 'Show information about a member.', 'Information', async ctx => { if (!requireGuild(ctx)) return; const m = memberFrom(ctx, ctx.args[0]) || ctx.member; if (!m) return ctx.reply({ embeds: [fail('Member not found.')] }); return ctx.reply({ embeds: [embed(m.user.tag, `ID: ${m.id}\nJoined: ${m.joinedTimestamp ? `<t:${Math.floor(m.joinedTimestamp / 1000)}:R>` : 'Unknown'}\nCreated: <t:${Math.floor(m.user.createdTimestamp / 1000)}:F>\nRoles: ${m.roles.cache.filter(r => r.id !== ctx.guild.id).map(r => r.toString()).slice(0, 15).join(', ') || 'None'}`)] }); }, { aliases: ['whois'] });
register('avatar', 'Show a member avatar.', 'Information', async ctx => { const m = memberFrom(ctx, ctx.args[0]); const u = m?.user || ctx.author; return ctx.reply({ embeds: [embed(`${u.username}'s avatar`, `[Open image](${u.displayAvatarURL({ size: 1024 })})`).setImage(u.displayAvatarURL({ size: 1024 }))] }); });
register('membercount', 'Show server member count.', 'Information', async ctx => { if (!requireGuild(ctx)) return; return ctx.reply({ embeds: [info(`Members in **${ctx.guild.name}**: ${ctx.guild.memberCount}`)] }); });
register('roleinfo', 'Show information about a role.', 'Information', async ctx => { if (!requireGuild(ctx)) return; const role = ctx.guild.roles.cache.find(r => r.id === String(ctx.args[0] || '').replace(/[<@&>]/g, '') || r.name.toLowerCase() === ctx.args.join(' ').toLowerCase()); if (!role) return ctx.reply({ embeds: [fail('Role not found. Mention a role or provide its ID/name.')] }); return ctx.reply({ embeds: [embed(role.name, `ID: ${role.id}\nMembers: ${role.members.size}\nColor: ${role.hexColor}\nPosition: ${role.position}\nMentionable: ${role.mentionable}`)] }); });
register('channelinfo', 'Show information about a channel.', 'Information', async ctx => { if (!requireGuild(ctx)) return; const ch = channelFrom(ctx, ctx.args[0]) || ctx.channel; return ctx.reply({ embeds: [embed(ch.name || 'Channel', `ID: ${ch.id}\nType: ${ChannelType[ch.type] || ch.type}\nCreated: <t:${Math.floor(ch.createdTimestamp / 1000)}:F>`)] }); });
register('say', 'Repeat a message (Manage Messages required).', 'Utility', async ctx => { if (!hasPerm(ctx, PermissionsBitField.Flags.ManageMessages)) return ctx.reply({ embeds: [fail('You need Manage Messages.')] }); const text = resolveText(ctx); if (!text) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}say <message>`)] }); await ctx.source.delete?.().catch(() => {}); return ctx.channel.send({ content: safeText(text), allowedMentions: { parse: [] } }); }, { slash: false });
register('embed', 'Send a simple embed (Manage Messages required).', 'Utility', async ctx => { if (!hasPerm(ctx, PermissionsBitField.Flags.ManageMessages)) return ctx.reply({ embeds: [fail('You need Manage Messages.')] }); const text = resolveText(ctx); if (!text) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}embed <text>`)] }); return ctx.channel.send({ embeds: [embed('PYRR OFFICIAL', text)], allowedMentions: { parse: [] } }); }, { slash: false });
register('poll', 'Create a yes/no poll.', 'Utility', async ctx => { const text = resolveText(ctx); if (!text) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}poll <question>`)] }); const m = await ctx.channel.send({ embeds: [embed('📊 Poll', text)] }); await m.react('👍').catch(() => {}); await m.react('👎').catch(() => {}); return ctx.reply({ content: 'Poll created.', ephemeral: !!ctx.interaction }); }, { slash: false });
register('choose', 'Choose one item from a list.', 'Fun', async ctx => { const items = resolveText(ctx).split('|').map(s => s.trim()).filter(Boolean); if (items.length < 2) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}choose item 1 | item 2`)] }); return ctx.reply({ embeds: [info(`I choose: **${items[Math.floor(Math.random() * items.length)]}**`)] }); });
register('8ball', 'Ask the magic 8-ball a question.', 'Fun', async ctx => { const q = resolveText(ctx); if (!q) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}8ball <question>`)] }); const answers = ['Yes, definitely.', 'It is likely.', 'Signs point to yes.', 'Ask again later.', 'Cannot predict that right now.', 'Probably not.', 'My answer is no.', 'The outlook is uncertain.']; return ctx.reply({ embeds: [embed('🎱 PYRR Magic 8-Ball', `**Question:** ${safeText(q, 1000)}\n**Answer:** ${answers[Math.floor(Math.random() * answers.length)]}`).setFooter({ text: 'Entertainment only — not a real prediction.' })] }); });
register('joke', 'Tell a clean joke.', 'Fun', async ctx => { const jokes = ['Why did the computer get cold? It left its Windows open.', 'Why was the math book sad? It had too many problems.', 'What do you call a sleeping bull? A bulldozer.', 'Why did the developer go broke? They used up all their cache.', 'Why do programmers prefer dark mode? Because light attracts bugs.']; return ctx.reply({ embeds: [info(jokes[Math.floor(Math.random() * jokes.length)])] }); });
register('roll', 'Roll a six-sided die.', 'Fun', async ctx => ctx.reply({ embeds: [info(`🎲 You rolled **${1 + Math.floor(Math.random() * 6)}**.`)] }));
register('coinflip', 'Flip a coin for fun (no wagers).', 'Fun', async ctx => ctx.reply({ embeds: [info(`🪙 **${Math.random() < 0.5 ? 'Heads' : 'Tails'}**`)] }));
register('8ballhelp', 'Explain the 8-ball command.', 'Fun', async ctx => ctx.reply({ embeds: [info(`Ask a question with \`${PREFIX}8ball <question>\`. For entertainment only.`)] }), { slash: false });

// ---------- MODERATION ----------
register('ban', 'Ban a member.', 'Moderation', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.BanMembers)) return ctx.reply({ embeds: [fail('You need Ban Members.')] }); const m = memberFrom(ctx, ctx.args[0]); if (!m) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}ban @member [reason]`)] }); if (m.id === ctx.author.id || m.id === client.user.id) return ctx.reply({ embeds: [fail('That member cannot be banned.')] }); const reason = ctx.args.slice(1).join(' ') || `By ${ctx.author.tag}`; await m.ban({ reason: safeText(reason, 400) }).catch(e => { throw e; }); await sendLog(ctx.guild, `${formatUser(m.user)} was banned by ${formatUser(ctx.author)}. Reason: ${reason}`); return ctx.reply({ embeds: [ok(`Banned **${m.user.tag}**. Reason: ${safeText(reason, 500)}`)] }); }, { mod: true, slash: true });
register('kick', 'Kick a member.', 'Moderation', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.KickMembers)) return ctx.reply({ embeds: [fail('You need Kick Members.')] }); const m = memberFrom(ctx, ctx.args[0]); if (!m) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}kick @member [reason]`)] }); if (m.id === ctx.author.id || m.id === client.user.id) return ctx.reply({ embeds: [fail('That member cannot be kicked.')] }); const reason = ctx.args.slice(1).join(' ') || `By ${ctx.author.tag}`; await m.kick(safeText(reason, 400)); await sendLog(ctx.guild, `${formatUser(m.user)} was kicked by ${formatUser(ctx.author)}. Reason: ${reason}`); return ctx.reply({ embeds: [ok(`Kicked **${m.user.tag}**.`)] }); }, { mod: true, slash: true });
register('timeout', 'Timeout a member, e.g. 10m.', 'Moderation', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.ModerateMembers)) return ctx.reply({ embeds: [fail('You need Moderate Members.')] }); const m = memberFrom(ctx, ctx.args[0]); const ms = durationMs(ctx.args[1]); if (!m || !ms) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}timeout @member 10m [reason]`)] }); if (m.id === ctx.author.id || m.id === client.user.id) return ctx.reply({ embeds: [fail('That member cannot be timed out.')] }); await m.timeout(ms, safeText(ctx.args.slice(2).join(' ') || `By ${ctx.author.tag}`, 400)); await sendLog(ctx.guild, `${formatUser(m.user)} timed out for ${durationLabel(ms)} by ${formatUser(ctx.author)}.`); return ctx.reply({ embeds: [ok(`Timed out **${m.user.tag}** for ${durationLabel(ms)}.`)] }); }, { mod: true, slash: false });
register('untimeout', 'Remove a member timeout.', 'Moderation', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.ModerateMembers)) return ctx.reply({ embeds: [fail('You need Moderate Members.')] }); const m = memberFrom(ctx, ctx.args[0]); if (!m) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}untimeout @member`)] }); await m.timeout(null, `Removed by ${ctx.author.tag}`); return ctx.reply({ embeds: [ok(`Removed timeout for **${m.user.tag}**.`)] }); }, { mod: true, slash: false });
register('purge', 'Delete recent messages.', 'Moderation', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.ManageMessages)) return ctx.reply({ embeds: [fail('You need Manage Messages.')] }); const n = Number(ctx.args[0]); if (!Number.isInteger(n) || n < 1 || n > 100) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}purge 1-100`)] }); const deleted = await ctx.channel.bulkDelete(n, true); const msg = await ctx.channel.send({ embeds: [ok(`Deleted ${deleted.size} messages.`)] }); setTimeout(() => msg.delete().catch(() => {}), 5000); }, { mod: true, slash: false });
register('slowmode', 'Set channel slowmode in seconds.', 'Moderation', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.ManageChannels)) return ctx.reply({ embeds: [fail('You need Manage Channels.')] }); const n = Number(ctx.args[0]); if (!Number.isInteger(n) || n < 0 || n > 21600) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}slowmode 0-21600`)] }); await ctx.channel.setRateLimitPerUser(n); return ctx.reply({ embeds: [ok(`Slowmode set to ${n} seconds.`)] }); }, { mod: true, slash: false });
register('lock', 'Lock the current text channel.', 'Moderation', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.ManageChannels)) return ctx.reply({ embeds: [fail('You need Manage Channels.')] }); await ctx.channel.permissionOverwrites.edit(ctx.guild.roles.everyone, { SendMessages: false }); return ctx.reply({ embeds: [ok('Channel locked for @everyone.')] }); }, { mod: true, slash: false });
register('unlock', 'Unlock the current text channel.', 'Moderation', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.ManageChannels)) return ctx.reply({ embeds: [fail('You need Manage Channels.')] }); await ctx.channel.permissionOverwrites.edit(ctx.guild.roles.everyone, { SendMessages: null }); return ctx.reply({ embeds: [ok('Channel unlocked for @everyone.')] }); }, { mod: true, slash: false });
register('warn', 'Warn a member.', 'Moderation', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.ModerateMembers)) return ctx.reply({ embeds: [fail('You need Moderate Members.')] }); const m = memberFrom(ctx, ctx.args[0]); if (!m) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}warn @member [reason]`)] }); const reason = ctx.args.slice(1).join(' ') || 'No reason given'; const count = addWarning(ctx.guild.id, m.id, reason, ctx.author.id); await sendLog(ctx.guild, `${formatUser(m.user)} warned by ${formatUser(ctx.author)}. Warning #${count}. Reason: ${reason}`); return ctx.reply({ embeds: [ok(`Warned **${m.user.tag}**. Total warnings: ${count}.`)] }); }, { mod: true, slash: false });
register('warnings', 'View a member warning count.', 'Moderation', async ctx => { if (!requireGuild(ctx)) return; const m = memberFrom(ctx, ctx.args[0]); if (!m) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}warnings @member`)] }); const list = guildData(ctx.guild.id).warnings[m.id] || []; return ctx.reply({ embeds: [embed(`Warnings: ${m.user.tag}`, list.length ? list.slice(-10).map((w, i) => `${i + 1}. ${w.reason} — <@${w.moderatorId}>`).join('\n') : 'No warnings recorded.')] }); }, { slash: false });
register('clearwarnings', 'Clear a member warning history.', 'Moderation', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.ModerateMembers)) return ctx.reply({ embeds: [fail('You need Moderate Members.')] }); const m = memberFrom(ctx, ctx.args[0]); if (!m) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}clearwarnings @member`)] }); guildData(ctx.guild.id).warnings[m.id] = []; saveDb(); return ctx.reply({ embeds: [ok(`Cleared warnings for **${m.user.tag}**.`)] }); }, { mod: true, slash: false });
register('nick', 'Change a member nickname.', 'Moderation', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.ManageNicknames)) return ctx.reply({ embeds: [fail('You need Manage Nicknames.')] }); const m = memberFrom(ctx, ctx.args[0]); if (!m) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}nick @member <nickname>`)] }); const nick = ctx.args.slice(1).join(' '); await m.setNickname(nick ? safeText(nick, 32) : null); return ctx.reply({ embeds: [ok(`Nickname updated for **${m.user.tag}**.`)] }); }, { mod: true, slash: false });
register('unban', 'Unban a user by ID.', 'Moderation', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.BanMembers)) return ctx.reply({ embeds: [fail('You need Ban Members.')] }); const id = ctx.args[0]; if (!/^\d{17,20}$/.test(id || '')) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}unban <user ID>`)] }); await ctx.guild.members.unban(id); return ctx.reply({ embeds: [ok(`Unbanned user ID ${id}.`)] }); }, { mod: true, slash: false });
register('roleadd', 'Add a role to a member.', 'Moderation', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.ManageRoles)) return ctx.reply({ embeds: [fail('You need Manage Roles.')] }); const m = memberFrom(ctx, ctx.args[0]); const roleId = String(ctx.args[1] || '').replace(/[<@&>]/g, ''); const role = ctx.guild.roles.cache.get(roleId) || ctx.guild.roles.cache.find(r => r.name.toLowerCase() === ctx.args.slice(1).join(' ').toLowerCase()); if (!m || !role) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}roleadd @member @role`)] }); await m.roles.add(role); return ctx.reply({ embeds: [ok(`Added ${role} to ${m}.`)] }); }, { mod: true, slash: false });
register('roleremove', 'Remove a role from a member.', 'Moderation', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.ManageRoles)) return ctx.reply({ embeds: [fail('You need Manage Roles.')] }); const m = memberFrom(ctx, ctx.args[0]); const roleId = String(ctx.args[1] || '').replace(/[<@&>]/g, ''); const role = ctx.guild.roles.cache.get(roleId) || ctx.guild.roles.cache.find(r => r.name.toLowerCase() === ctx.args.slice(1).join(' ').toLowerCase()); if (!m || !role) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}roleremove @member @role`)] }); await m.roles.remove(role); return ctx.reply({ embeds: [ok(`Removed ${role} from ${m}.`)] }); }, { mod: true, slash: false });
register('dehoist', 'Remove leading punctuation from a nickname.', 'Moderation', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.ManageNicknames)) return ctx.reply({ embeds: [fail('You need Manage Nicknames.')] }); const m = memberFrom(ctx, ctx.args[0]); if (!m) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}dehoist @member`)] }); const name = (m.displayName || m.user.username).replace(/^[^a-zA-Z0-9]+/, '').slice(0, 32); await m.setNickname(name || null); return ctx.reply({ embeds: [ok(`Updated nickname for ${m.user.tag}.`)] }); }, { mod: true, slash: false });

// ---------- CONFIGURATION / PROTECTION ----------
register('setlog', 'Set the server log channel.', 'Configuration', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.ManageGuild)) return ctx.reply({ embeds: [fail('You need Manage Server.')] }); const ch = channelFrom(ctx, ctx.args[0]) || ctx.channel; if (!ch.isTextBased()) return ctx.reply({ embeds: [fail('Choose a text channel.')] }); guildData(ctx.guild.id).logChannel = ch.id; saveDb(); return ctx.reply({ embeds: [ok(`Log channel set to ${ch}.`)] }); }, { admin: true, slash: false });
register('setwelcome', 'Set the welcome channel.', 'Configuration', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.ManageGuild)) return ctx.reply({ embeds: [fail('You need Manage Server.')] }); const ch = channelFrom(ctx, ctx.args[0]) || ctx.channel; guildData(ctx.guild.id).welcomeChannel = ch.id; saveDb(); return ctx.reply({ embeds: [ok(`Welcome channel set to ${ch}.`)] }); }, { admin: true, slash: false });
register('setleave', 'Set the leave channel.', 'Configuration', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.ManageGuild)) return ctx.reply({ embeds: [fail('You need Manage Server.')] }); const ch = channelFrom(ctx, ctx.args[0]) || ctx.channel; guildData(ctx.guild.id).leaveChannel = ch.id; saveDb(); return ctx.reply({ embeds: [ok(`Leave channel set to ${ch}.`)] }); }, { admin: true, slash: false });
register('setautorole', 'Set a role to assign to new members.', 'Configuration', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.ManageGuild)) return ctx.reply({ embeds: [fail('You need Manage Server.')] }); const id = String(ctx.args[0] || '').replace(/[<@&>]/g, ''); const role = ctx.guild.roles.cache.get(id); if (!role) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}setautorole @role`)] }); guildData(ctx.guild.id).autorole = role.id; saveDb(); return ctx.reply({ embeds: [ok(`Autorole set to ${role}.`)] }); }, { admin: true, slash: false });
register('setmuterole', 'Set the muted role.', 'Configuration', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.ManageGuild)) return ctx.reply({ embeds: [fail('You need Manage Server.')] }); const id = String(ctx.args[0] || '').replace(/[<@&>]/g, ''); const role = ctx.guild.roles.cache.get(id); if (!role) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}setmuterole @role`)] }); guildData(ctx.guild.id).mutedRole = role.id; saveDb(); return ctx.reply({ embeds: [ok(`Muted role set to ${role}.`)] }); }, { admin: true, slash: false });
register('antinuke', 'Toggle anti-nuke event alerts.', 'Protection', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.Administrator)) return ctx.reply({ embeds: [fail('Administrator permission required.')] }); const value = (ctx.args[0] || '').toLowerCase(); if (!['on', 'off', 'status'].includes(value)) return ctx.reply({ embeds: [info(`Usage: ${PREFIX}antinuke on|off|status\nThis setting logs suspicious destructive events; it does not automatically ban users.`)] }); const g = guildData(ctx.guild.id); if (value !== 'status') { g.antinuke = value === 'on'; saveDb(); } return ctx.reply({ embeds: [info(`Anti-nuke alerts: **${g.antinuke ? 'ON' : 'OFF'}**\nAlerts go to the configured log channel.`)] }); }, { admin: true, slash: false });
register('antiraid', 'Toggle join-spike alerts.', 'Protection', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.Administrator)) return ctx.reply({ embeds: [fail('Administrator permission required.')] }); const value = (ctx.args[0] || '').toLowerCase(); if (!['on', 'off', 'status'].includes(value)) return ctx.reply({ embeds: [info(`Usage: ${PREFIX}antiraid on|off|status`)] }); const g = guildData(ctx.guild.id); if (value !== 'status') { g.antiraid = value === 'on'; saveDb(); } return ctx.reply({ embeds: [info(`Anti-raid join alerts: **${g.antiraid ? 'ON' : 'OFF'}**`)] }); }, { admin: true, slash: false });
register('automod', 'Toggle basic automod alerts.', 'Protection', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.Administrator)) return ctx.reply({ embeds: [fail('Administrator permission required.')] }); const value = (ctx.args[0] || '').toLowerCase(); if (!['on', 'off', 'status'].includes(value)) return ctx.reply({ embeds: [info(`Usage: ${PREFIX}automod on|off|status`)] }); const g = guildData(ctx.guild.id); if (value !== 'status') { g.automod = value === 'on'; saveDb(); } return ctx.reply({ embeds: [info(`Automod keyword/link alerts: **${g.automod ? 'ON' : 'OFF'}**`)] }); }, { admin: true, slash: false });
register('protection', 'Show protection settings.', 'Protection', async ctx => { if (!requireGuild(ctx)) return; const g = guildData(ctx.guild.id); return ctx.reply({ embeds: [embed('Protection Settings', `Anti-nuke alerts: ${g.antinuke ? 'ON' : 'OFF'}\nAnti-raid alerts: ${g.antiraid ? 'ON' : 'OFF'}\nAutomod alerts: ${g.automod ? 'ON' : 'OFF'}\nLog channel: ${g.logChannel ? `<#${g.logChannel}>` : 'Not set'}`)] }); }, { slash: false });
register('setwelcome-text', 'Set welcome text using {user} and {server}.', 'Configuration', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.ManageGuild)) return ctx.reply({ embeds: [fail('You need Manage Server.')] }); const t = resolveText(ctx); if (!t) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}setwelcome-text Welcome {user} to {server}!`)] }); guildData(ctx.guild.id).welcomeText = safeText(t, 1000); saveDb(); return ctx.reply({ embeds: [ok('Welcome text saved.')] }); }, { admin: true, slash: false });
register('setleave-text', 'Set leave text using {user} and {server}.', 'Configuration', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.ManageGuild)) return ctx.reply({ embeds: [fail('You need Manage Server.')] }); const t = resolveText(ctx); if (!t) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}setleave-text {user} left {server}.`)] }); guildData(ctx.guild.id).leaveText = safeText(t, 1000); saveDb(); return ctx.reply({ embeds: [ok('Leave text saved.')] }); }, { admin: true, slash: false });

// ---------- TICKETS ----------
register('ticketsetup', 'Create a basic ticket panel in this channel.', 'Tickets', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.ManageChannels)) return ctx.reply({ embeds: [fail('You need Manage Channels.')] }); const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('pyrr_ticket_open').setLabel('Create Ticket').setStyle(ButtonStyle.Primary).setEmoji('🎫')); const msg = await ctx.channel.send({ embeds: [embed('Support Tickets', 'Press the button below to open a private support ticket.')], components: [row] }); guildData(ctx.guild.id).ticketPanel = { channelId: ctx.channel.id, messageId: msg.id }; saveDb(); return ctx.reply({ embeds: [ok('Ticket panel created.')] }); }, { admin: true, slash: false });
register('ticketclose', 'Close the current ticket channel.', 'Tickets', async ctx => { if (!requireGuild(ctx)) return; if (!ctx.channel.name?.startsWith('ticket-')) return ctx.reply({ embeds: [fail('Use this command inside a ticket channel.')] }); if (!hasPerm(ctx, PermissionsBitField.Flags.ManageChannels)) return ctx.reply({ embeds: [fail('You need Manage Channels.')] }); await ctx.reply({ embeds: [ok('Ticket will be deleted in 5 seconds.')] }); setTimeout(() => ctx.channel.delete('Ticket closed').catch(() => {}), 5000); }, { mod: true, slash: false });
register('tickethelp', 'Show ticket commands.', 'Tickets', async ctx => ctx.reply({ embeds: [info(`\`${PREFIX}ticketsetup\` — create panel (Manage Channels)\n\`${PREFIX}ticketclose\` — close ticket channel`)] }), { slash: false });

// ---------- SAFE GENERIC COMMANDS: 250+ UNIQUE NAMES TOTAL ----------
// These commands provide lightweight, functional server/help responses.
const utilityCommands = {
  Utility: ['time','date','timestamp','servericon','serverbanner','botavatar','permissions','channelid','userid','rolelist','channellist','emojis','emoji-list','boosts','boostlevel','created','joined','memberlist','onlinecount','botcount','human-count','randomnumber','reverse','uppercase','lowercase','charcount','wordcount','mockcase','clap','spoiler','markdown','quote-text','clearreminders','pollhelp','embedhelp','inviteinfo','links','status','supportinfo','prefixinfo','uptimeformat','pingcheck','health','diagnostics','permissionscheck','threadinfo','foruminfo','stageinfo','voiceinfo','rolecount','channelcount','emojiinfo','stickerinfo','guildcreated','usercreated','snowflake','hexcolor','color','choosecolor','formatduration','parse-duration','sayhelp','serverfeatures','boostinfo','bannerinfo','memberposition','roleposition','channelposition'],
  Fun: ['compliment','fortune','riddle','riddleanswer','dadjoke','pun','fact','animalfact','spacefact','techfact','quote','motivate','inspire','goodnight','goodmorning','hello','hug','highfive','pat','wave','cheer','dance','celebrate','clapback','vibe','mood','aesthetic','shipname','friendship','teamname','nickname','randomname','superpower','weakness','wouldyourather','wyr','truth','dare','neverhaveiever','roseday','complimentme','ratevibe','guessnumber','guessinghelp','wordoftheday','alphabet','countdown','emoji','emojify','decodeemoji','reverse-text','mirror','echo','repeat','sayhi','goodluck','congrats','thankyou','applause','boo','bruh','lol','lmao','gg','skillissue','wholesome','randomfact','todayfact','funfact','riddleme','jokehelp','8balltips','storyprompt','charactername','petname','teamcheer','picknumber','pickcolor','pickemoji'],
  Information: ['helpmod','helputility','helpfun','helpprotection','helptickets','helpconfig','helpinfo','helproles','helpserver','helpautomod','helpwelcome','helpmoderation','commandcount','categorylist','botcommands','botversion','botowner','serverowner','serverregion','serverboosts','memberstatus','memberjoined','membercreated','userbanner','useravatar','usermention','userdisplayname','userdiscriminator','guildid','guildname','guildowner','guildmembers','guildroles','guildchannels','guildemojis','guildstickers','guildboosters','guildverification','guildnotifications','guildafk','guildsystemchannel','guildruleschannel','guildpublicupdates','botpermissions','botinvite','privacy','terms','aboutpyrr','creator','twitch','socials','linkshelp','supporthelp','featurelist','changelog','version','uptimecheck','pinghelp'],
  Roles: ['rolehelp','rolecreateinfo','rolecolorinfo','rolementioninfo','rolepermissions','rolemembers','rolehierarchy','roleorder','roleusage','roleaudit','rolecheck','roleassignhelp','rolecleanuphelp','autoroleinfo','muteroleinfo','roleiconinfo','rolementionable','rolehoistinfo','rolecompare','rolecountinfo'],
  'Server Tools': ['welcomehelp','leavehelp','loghelp','serverrules','ruleshelp','announcements','announcementhelp','suggestionhelp','suggestionstatus','suggestioncreatehelp','starboardhelp','reactionroleshelp','giveawayhelp','eventhelp','eventinfo','pollstatus','pollcreatehelp','slowmodehelp','lockhelp','unlockhelp','purgehelp','audithelp','modlog','logstatus','welcome-preview','leave-preview','ticketstatus','ticketpanelinfo','tickettranscripthelp','verifyhelp','verificationstatus','autorolehelp','setloghelp','setwelcomehelp','setleavehelp','setmuterolehelp','setautorolehelp','serverconfig','confighelp','featurestatus','channelrules','reporthelp','reportstatus','appealhelp','appealstatus'],
  Protection: ['antinukehelp','antiraidhelp','automodhelp','protectionhelp','raidstatus','nuke-alerts','joinalerts','linkfilterhelp','spamfilterhelp','capsfilterhelp','mentionfilterhelp','keywordfilterhelp','invitefilterhelp','scamfilterhelp','securitystatus','auditstatus','safetycheck','permissionsaudit','adminlist','modlist','trustedroles','trustedusers','lockdownstatus','lockdownhelp','securityhelp','protectionstatus','botguard','webhookinfo','webhooklist','auditloghelp'],
  Moderation: ['banhelp','kickhelp','timeouthelp','untimeouthelp','warnhelp','warningshelp','clearwarningshelp','unbanhelp','nickhelp','dehoisthelp','roleaddhelp','roleremovehelp','purgeinfo','slowmodeinfo','lockinfo','unlockinfo','modhelp','moderatorinfo','modstats','warncount','casehelp','cases','reasonhelp','moderationrules','memberhistory','infractions','infractionhelp','timeoutinfo','kickinfo','baninfo','modcommands','auditreason','clearwarnhelp'],
  Tickets: ['ticketinfo','ticketpanel','ticketcategory','ticketpermissions','tickettranscript','ticketstats','ticketrules','ticketclosehelp','ticketopenhelp','ticketclaimhelp','ticketaddhelp','ticketremovehelp','ticketrenamehelp','ticketarchivehelp','ticketdeletehelp'],
  Configuration: ['config','configview','configstatus','configresethelp','welcomeconfig','leaveconfig','autoroleconfig','muteroleconfig','logconfig','prefixconfig','featureconfig','setloginfo','setwelcomeinfo','setleaveinfo','setautoroleinfo','setmuteroleinfo','setwelcome-text-help','setleave-text-help','databaseinfo','datahelp','settings','settingshelp','setuphelp','setupstatus','setupcheck','setupguide','botsetup','server-setup','configuration-list']
};
const genericResponses = {
  Utility: name => `**${name}** is available in PYRR OFFICIAL.\nPrefix: \`${PREFIX}\`\nUse \`${PREFIX}help\` to view command categories.`,
  Fun: name => {
    const replies = {
      compliment: ['You bring good energy to the room.', 'You make your community brighter.', 'Your effort matters.'],
      fortune: ['A good opportunity may come from steady effort.', 'Be patient with your next decision.', 'Small progress still counts.'],
      riddle: ['What has keys but cannot open locks? A piano.', 'What gets wetter as it dries? A towel.', 'What has a face and two hands but no arms? A clock.'],
      dadjoke: ['I used to hate facial hair, but then it grew on me.', 'I only know 25 letters of the alphabet. I do not know y.', 'I told my computer I needed a break, and it said no problem.'],
      goodmorning: ['Good morning! Have a steady and positive day.'], goodnight: ['Good night! Rest well and take care.'], hello: ['Hello! Welcome to PYRR OFFICIAL.'], goodluck: ['Good luck! You have got this.'], congrats: ['Congratulations! Keep going.'], thankyou: ['You are appreciated.'], motivate: ['Focus on progress, not perfection.'], inspire: ['A little consistency can go a long way.'], quote: ['“Great things are done by a series of small things brought together.” — Vincent van Gogh'], randomfact: ['Octopuses have three hearts.'], spacefact: ['A day on Venus is longer than its year.'], techfact: ['The first computer bug was famously documented in 1947.'], animalfact: ['Sea otters sometimes hold hands while resting.'], riddleanswer: ['Try the riddle command first, then reveal the answer.'], truth: ['What is something you are proud of learning?'], dare: ['Give someone a sincere compliment.'], wouldyourather: ['Would you rather explore the ocean or outer space?'], wyr: ['Would you rather explore the ocean or outer space?']
    };
    const arr = replies[name] || [`Here is your ${name} prompt: keep it friendly and have fun!`];
    return arr[Math.floor(Math.random() * arr.length)];
  },
  Information: name => `**${name}**\nPYRR OFFICIAL • Creator: ${CREATOR}\nUse \`${PREFIX}help\` for command categories.`,
  Roles: name => `**${name}** — role information utility.\nUse \`${PREFIX}roleinfo @role\` to inspect a role.`,
  'Server Tools': name => `**${name}** — server setup guidance.\nUse \`${PREFIX}help configuration\` or ask a server administrator.`,
  Protection: name => `**${name}** — protection guidance.\nCheck current settings with \`${PREFIX}protection\`.`,
  Moderation: name => `**${name}** — moderation help.\nUse \`${PREFIX}help moderation\` for the main moderation commands.`,
  Tickets: name => `**${name}** — ticket help.\nUse \`${PREFIX}ticketsetup\` to create a ticket panel.`,
  Configuration: name => `**${name}** — configuration help.\nUse \`${PREFIX}protection\` to review protection toggles.`
};
for (const [category, names] of Object.entries(utilityCommands)) {
  for (const name of names) {
    register(name, `${name.replace(/[-_]/g, ' ')} command.`, category, async ctx => {
      if (name === 'time') return ctx.reply({ embeds: [info(`Current bot time: <t:${Math.floor(Date.now() / 1000)}:F>`)] });
      if (name === 'date') return ctx.reply({ embeds: [info(new Date().toUTCString())] });
      if (name === 'timestamp') return ctx.reply({ embeds: [info(`Unix timestamp: ${Math.floor(Date.now() / 1000)}`)] });
      if (name === 'servericon' && ctx.guild?.iconURL()) return ctx.reply({ embeds: [embed(`${ctx.guild.name} icon`, '').setImage(ctx.guild.iconURL({ size: 1024 }))] });
      if (name === 'servericon') return ctx.reply({ embeds: [fail('No server icon is set, or this command needs a server.')] });
      if (name === 'randomnumber') { const n = Number(ctx.args[0] || 100); if (!Number.isInteger(n) || n < 1 || n > 1000000) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}randomnumber <max 1-1000000>`)] }); return ctx.reply({ embeds: [info(`Random number: **${1 + Math.floor(Math.random() * n)}**`)] }); }
      if (name === 'reverse' || name === 'reverse-text') return ctx.reply({ embeds: [info(resolveText(ctx).split('').reverse().join('') || 'Add text after the command.')] });
      if (name === 'uppercase') return ctx.reply({ embeds: [info(resolveText(ctx).toUpperCase() || 'Add text after the command.')] });
      if (name === 'lowercase') return ctx.reply({ embeds: [info(resolveText(ctx).toLowerCase() || 'Add text after the command.')] });
      if (name === 'charcount') return ctx.reply({ embeds: [info(`Characters: ${resolveText(ctx).length}`)] });
      if (name === 'wordcount') return ctx.reply({ embeds: [info(`Words: ${resolveText(ctx).trim() ? resolveText(ctx).trim().split(/\s+/).length : 0}`)] });
      if (name === 'mockcase') return ctx.reply({ embeds: [info([...resolveText(ctx)].map((c, i) => i % 2 ? c.toLowerCase() : c.toUpperCase()).join('') || 'Add text after the command.')] });
      if (name === 'clap') return ctx.reply({ embeds: [info(resolveText(ctx).split(/\s+/).filter(Boolean).join(' 👏 ') || 'Add text after the command.')] });
      if (name === 'spoiler') return ctx.reply({ embeds: [info(`||${safeText(resolveText(ctx), 1500)}||`)] });
      if (name === 'emoji') return ctx.reply({ embeds: [info('😀 😎 🎉 💜 🔥 ✨ 🌙 🚀')] });
      if (name === 'serverrules') return ctx.reply({ embeds: [embed('Suggested Server Rules', '1. Be respectful.\n2. No spam or harassment.\n3. Follow Discord Community Guidelines.\n4. Keep content in the correct channels.\n5. Follow moderator instructions.')] });
      if (name === 'creator' || name === 'botowner') return ctx.reply({ embeds: [info(`Creator: **${CREATOR}**`)] });
      if (name === 'twitch' || name === 'socials') return ctx.reply({ embeds: [info(`Twitch: ${TWITCH_URL}`)] });
      if (name === 'commandcount') return ctx.reply({ embeds: [info(`Unique commands: **${commandMap.size}**`)] });
      if (name === 'categorylist') return ctx.reply({ embeds: [info([...new Set([...commandMap.values()].map(c => c.category))].sort().join(', '))] });
      if (name === 'botcommands') return ctx.reply({ embeds: [info(`Total commands: ${commandMap.size}. Use \`${PREFIX}help\` for categories.`)] });
      if (name === 'membercount' || name === 'guildmembers') return ctx.guild ? ctx.reply({ embeds: [info(`Members: ${ctx.guild.memberCount}`)] }) : ctx.reply({ embeds: [fail('Server only.')] });
      if (name === 'onlinecount') return ctx.guild ? ctx.reply({ embeds: [info(`Cached online members: ${ctx.guild.members.cache.filter(m => m.presence?.status && m.presence.status !== 'offline').size}`)] }) : ctx.reply({ embeds: [fail('Server only.')] });
      if (name === 'rolelist' && ctx.guild) return ctx.reply({ embeds: [embed('Roles', ctx.guild.roles.cache.sort((a,b) => b.position-a.position).map(r => r.name).slice(0, 50).join(', ').slice(0, 4000))] });
      if (name === 'channellist' && ctx.guild) return ctx.reply({ embeds: [embed('Channels', ctx.guild.channels.cache.map(c => `#${c.name}`).slice(0, 60).join('\n').slice(0, 4000))] });
      if (name === 'permissions' || name === 'permissionscheck') return ctx.reply({ embeds: [info(ctx.member?.permissions?.toArray?.().join(', ') || 'Permission list unavailable.')] });
      if (name === 'status') return ctx.reply({ embeds: [info(`Online • ${client.guilds.cache.size} servers • ${commandMap.size} commands`)] });
      const response = genericResponses[category] ? genericResponses[category](name) : `Command: ${name}`;
      return ctx.reply({ embeds: [info(response)] });
    }, { slash: ['time','date','timestamp','randomnumber','reverse','uppercase','lowercase','charcount','wordcount','compliment','fortune','riddle','dadjoke','fact','quote','motivate','hello','goodluck','congrats','thankyou'].includes(name) });
  }
}

// ---------- ADDITIONAL USEFUL COMMANDS ----------
register('remindme', 'Set a reminder in minutes (current session only).', 'Utility', async ctx => { const minutes = Number(ctx.args[0]); const text = ctx.args.slice(1).join(' '); if (!Number.isInteger(minutes) || minutes < 1 || minutes > 10080 || !text) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}remindme <minutes> <message>`)] }); await ctx.reply({ embeds: [ok(`Reminder set for ${minutes} minute(s).`)] }); setTimeout(() => ctx.author.send({ embeds: [info(`Reminder: ${text}`)] }).catch(() => {}), minutes * 60000); }, { slash: false });
register('report', 'Send a member report to the configured log channel.', 'Server Tools', async ctx => { if (!requireGuild(ctx)) return; const text = resolveText(ctx); if (!text) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}report <details>`)] }); await sendLog(ctx.guild, `User report by ${formatUser(ctx.author)} in <#${ctx.channel.id}>: ${safeText(text, 1000)}`); return ctx.reply({ embeds: [ok('Report submitted to the configured log channel, if one is set.')] }); }, { slash: false });
register('suggest', 'Submit a suggestion to the configured log channel.', 'Server Tools', async ctx => { if (!requireGuild(ctx)) return; const text = resolveText(ctx); if (!text) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}suggest <suggestion>`)] }); await sendLog(ctx.guild, `Suggestion by ${formatUser(ctx.author)}: ${safeText(text, 1000)}`); return ctx.reply({ embeds: [ok('Suggestion submitted to the configured log channel, if one is set.')] }); }, { slash: false });
register('announce', 'Post an announcement (Manage Messages required).', 'Server Tools', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.ManageMessages)) return ctx.reply({ embeds: [fail('You need Manage Messages.')] }); const text = resolveText(ctx); if (!text) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}announce <message>`)] }); return ctx.channel.send({ embeds: [embed('📢 Announcement', safeText(text, 3500))], allowedMentions: { parse: [] } }); }, { mod: true, slash: false });
register('createchannel', 'Create a text channel (Manage Channels required).', 'Server Tools', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.ManageChannels)) return ctx.reply({ embeds: [fail('You need Manage Channels.')] }); const name = ctx.args.join('-').toLowerCase().replace(/[^a-z0-9-]/g, '').slice(0, 90); if (!name) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}createchannel <channel-name>`)] }); const ch = await ctx.guild.channels.create({ name, type: ChannelType.GuildText, reason: `Requested by ${ctx.author.tag}` }); return ctx.reply({ embeds: [ok(`Created ${ch}.`)] }); }, { mod: true, slash: false });
register('createrole', 'Create a basic role (Manage Roles required).', 'Server Tools', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.ManageRoles)) return ctx.reply({ embeds: [fail('You need Manage Roles.')] }); const name = resolveText(ctx); if (!name) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}createrole <role name>`)] }); const role = await ctx.guild.roles.create({ name: safeText(name, 100), reason: `Requested by ${ctx.author.tag}` }); return ctx.reply({ embeds: [ok(`Created role ${role}.`)] }); }, { mod: true, slash: false });
register('deletechannel', 'Delete a channel by mention or ID (Manage Channels required).', 'Server Tools', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.ManageChannels)) return ctx.reply({ embeds: [fail('You need Manage Channels.')] }); const ch = channelFrom(ctx, ctx.args[0]); if (!ch) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}deletechannel #channel`)] }); const name = ch.name; await ch.delete(`Requested by ${ctx.author.tag}`); return ctx.reply({ embeds: [ok(`Deleted channel #${name}.`)] }).catch(() => {}); }, { mod: true, slash: false });
register('delete-role', 'Delete a role by ID (Manage Roles required).', 'Server Tools', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.ManageRoles)) return ctx.reply({ embeds: [fail('You need Manage Roles.')] }); const id = String(ctx.args[0] || '').replace(/[<@&>]/g, ''); const role = ctx.guild.roles.cache.get(id); if (!role || role.managed || role.id === ctx.guild.id) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}delete-role @role (cannot delete managed/everyone roles)`)] }); await role.delete(`Requested by ${ctx.author.tag}`); return ctx.reply({ embeds: [ok(`Deleted role ${role.name}.`)] }); }, { mod: true, slash: false });
register('lockdown', 'Lock all text channels for @everyone (Manage Channels required).', 'Moderation', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.Administrator)) return ctx.reply({ embeds: [fail('Administrator permission required.')] }); let changed = 0; for (const ch of ctx.guild.channels.cache.values()) { if (ch.isTextBased() && ch.permissionOverwrites) { await ch.permissionOverwrites.edit(ctx.guild.roles.everyone, { SendMessages: false }).then(() => changed++).catch(() => {}); } } return ctx.reply({ embeds: [ok(`Lockdown applied to ${changed} text channels. Use ${PREFIX}unlockdown to reverse.`)] }); }, { admin: true, slash: false });
register('unlockdown', 'Remove lockdown from text channels.', 'Moderation', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.Administrator)) return ctx.reply({ embeds: [fail('Administrator permission required.')] }); let changed = 0; for (const ch of ctx.guild.channels.cache.values()) { if (ch.isTextBased() && ch.permissionOverwrites) { await ch.permissionOverwrites.edit(ctx.guild.roles.everyone, { SendMessages: null }).then(() => changed++).catch(() => {}); } } return ctx.reply({ embeds: [ok(`Lockdown removed from ${changed} text channels.`)] }); }, { admin: true, slash: false });
register('purgebots', 'Delete recent bot messages (Manage Messages required).', 'Moderation', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.ManageMessages)) return ctx.reply({ embeds: [fail('You need Manage Messages.')] }); const n = Number(ctx.args[0]); if (!Number.isInteger(n) || n < 1 || n > 100) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}purgebots 1-100`)] }); const msgs = await ctx.channel.messages.fetch({ limit: n }); const bots = msgs.filter(m => m.author.bot); const deleted = await ctx.channel.bulkDelete(bots, true); return ctx.reply({ embeds: [ok(`Deleted ${deleted.size} recent bot messages.`)] }); }, { mod: true, slash: false });
register('purgeuser', 'Delete recent messages by a specified member.', 'Moderation', async ctx => { if (!requireGuild(ctx)) return; if (!hasPerm(ctx, PermissionsBitField.Flags.ManageMessages)) return ctx.reply({ embeds: [fail('You need Manage Messages.')] }); const m = memberFrom(ctx, ctx.args[0]); const n = Number(ctx.args[1]); if (!m || !Number.isInteger(n) || n < 1 || n > 100) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}purgeuser @member 1-100`)] }); const msgs = await ctx.channel.messages.fetch({ limit: Math.min(100, n + 10) }); const targets = msgs.filter(x => x.author.id === m.id).first(n); const deleted = await ctx.channel.bulkDelete(targets, true); return ctx.reply({ embeds: [ok(`Deleted ${deleted.size} messages by ${m.user.tag}.`)] }); }, { mod: true, slash: false });
register('clear', 'Alias for purge.', 'Moderation', async ctx => { const n = Number(ctx.args[0]); if (!Number.isInteger(n) || n < 1 || n > 100) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}clear 1-100`)] }); if (!hasPerm(ctx, PermissionsBitField.Flags.ManageMessages)) return ctx.reply({ embeds: [fail('You need Manage Messages.')] }); const deleted = await ctx.channel.bulkDelete(n, true); return ctx.reply({ embeds: [ok(`Deleted ${deleted.size} messages.`)] }); }, { mod: true, slash: false });
register('serverstats', 'Show basic server statistics.', 'Information', async ctx => { if (!requireGuild(ctx)) return; const g = ctx.guild; return ctx.reply({ embeds: [embed(`${g.name} Statistics`, `Members: ${g.memberCount}\nRoles: ${g.roles.cache.size}\nChannels: ${g.channels.cache.size}\nEmojis: ${g.emojis.cache.size}\nBoosts: ${g.premiumSubscriptionCount || 0}`)] }); });
register('memberroles', 'List roles for a member.', 'Information', async ctx => { if (!requireGuild(ctx)) return; const m = memberFrom(ctx, ctx.args[0]) || ctx.member; return ctx.reply({ embeds: [embed(`Roles for ${m.user.tag}`, m.roles.cache.filter(r => r.id !== ctx.guild.id).map(r => r.toString()).slice(0, 40).join(', ') || 'No roles')] }); });
register('pollmulti', 'Create a poll with up to five options separated by |.', 'Utility', async ctx => { const parts = resolveText(ctx).split('|').map(s => s.trim()).filter(Boolean); if (parts.length < 2 || parts.length > 5) return ctx.reply({ embeds: [fail(`Usage: ${PREFIX}pollmulti Question | Option 1 | Option 2 (up to 5 options)`)] }); const [question, ...opts] = parts; const emojis = ['1️⃣','2️⃣','3️⃣','4️⃣','5️⃣']; const msg = await ctx.channel.send({ embeds: [embed(`📊 ${safeText(question, 200)}`, opts.map((o,i) => `${emojis[i]} ${safeText(o, 200)}`).join('\n'))] }); for (let i=0;i<opts.length;i++) await msg.react(emojis[i]).catch(() => {}); return ctx.reply({ embeds: [ok('Poll created.')] }); }, { slash: false });

// ---------- JOIN / LEAVE, AUTOMOD ALERTS, AUDIT ALERTS ----------
client.on('guildMemberAdd', async member => {
  const g = guildData(member.guild.id);
  if (g.autorole) { const role = member.guild.roles.cache.get(g.autorole); if (role) await member.roles.add(role, 'PYRR autorole').catch(() => {}); }
  if (g.welcomeChannel) { const ch = member.guild.channels.cache.get(g.welcomeChannel); if (ch?.isTextBased()) await ch.send({ embeds: [embed('Welcome!', g.welcomeText.replaceAll('{user}', `<@${member.id}>`).replaceAll('{server}', member.guild.name))] }).catch(() => {}); }
  if (g.antiraid) await sendLog(member.guild, `Join alert: ${formatUser(member.user)} joined. Current member count: ${member.guild.memberCount}.`);
});
client.on('guildMemberRemove', async member => {
  const g = guildData(member.guild.id);
  if (g.leaveChannel) { const ch = member.guild.channels.cache.get(g.leaveChannel); if (ch?.isTextBased()) await ch.send({ embeds: [embed('Goodbye', g.leaveText.replaceAll('{user}', member.user.tag).replaceAll('{server}', member.guild.name))] }).catch(() => {}); }
});
client.on('messageCreate', async message => {
  if (!message.guild || message.author.bot) return;
  const g = guildData(message.guild.id);
  if (g.automod) {
    const content = message.content || '';
    const hasInvite = /discord\.gg\//i.test(content);
    const spam = content.length > 1800 || /(.)\1{18,}/u.test(content);
    if (hasInvite || spam) { await sendLog(message.guild, `Automod alert from ${formatUser(message.author)} in <#${message.channel.id}>. Reason: ${hasInvite ? 'invite link' : 'repeated/oversized text'}.`); }
  }
  const prefix = PREFIX;
  if (!message.content.toLowerCase().startsWith(prefix.toLowerCase())) return;
  const body = message.content.slice(prefix.length).trim();
  if (!body) return;
  const parts = body.match(/(?:"([^"]*)"|'([^']*)'|\S+)/g) || [];
  const args = parts.map(p => p.replace(/^['"]|['"]$/g, ''));
  const inputName = (args.shift() || '').toLowerCase();
  const name = aliases.get(inputName) || inputName;
  const cmd = commandMap.get(name);
  if (!cmd) return;
  if (g.disabled.includes(name)) return message.reply({ embeds: [fail('This command is disabled in this server.')] }).catch(() => {});
  if (cmd.admin && !message.member.permissions.has(PermissionsBitField.Flags.Administrator)) return message.reply({ embeds: [fail('Administrator permission required.')] }).catch(() => {});
  if (cmd.mod && !message.member.permissions.has(PermissionsBitField.Flags.ModerateMembers) && !message.member.permissions.has(PermissionsBitField.Flags.ManageMessages) && !message.member.permissions.has(PermissionsBitField.Flags.Administrator)) return message.reply({ embeds: [fail('You need moderation permissions to use this command.')] }).catch(() => {});
  if (cmd.owner && !isOwner({ author: message.author })) return message.reply({ embeds: [fail('Bot owner only.')] }).catch(() => {});
  if (cmd.cooldown) { const key = `${message.author.id}:${name}`; const last = cooldowns.get(key) || 0; if (Date.now() - last < cmd.cooldown) return message.reply({ embeds: [fail(`Wait ${Math.ceil((cmd.cooldown - (Date.now() - last))/1000)}s before using this again.`)] }).catch(() => {}); cooldowns.set(key, Date.now()); }
  try { await cmd.run(ctxForMessage(message, args)); }
  catch (error) { console.error(`[PYRR] Command ${name} failed:`, error); const payload = { embeds: [fail('The command failed. Check the bot permissions and try again.')] }; if (message.channel?.isSendable()) await message.reply(payload).catch(() => {}); }
});

// Log destructive events when protection alerts are enabled. Alerts only;
// this bot intentionally does not automatically ban an audit-log actor.
const destructiveEvents = [
  [AuditLogEvent.ChannelDelete, 'channel deleted'],
  [AuditLogEvent.RoleDelete, 'role deleted'],
  [AuditLogEvent.WebhookCreate, 'webhook created'],
  [AuditLogEvent.GuildUpdate, 'server settings updated']
];
for (const [eventType, label] of destructiveEvents) {
  client.on('guildAuditLogEntryCreate', async (entry, guild) => {
    if (entry.action !== eventType) return;
    const g = guildData(guild.id);
    if (g.antinuke) await sendLog(guild, `Anti-nuke alert: ${label}. Actor: ${entry.executor ? formatUser(entry.executor) : 'Unknown'}. This is an alert only; verify audit logs before taking action.`);
  });
}

// ---------- BUTTONS / TICKETS ----------
client.on('interactionCreate', async interaction => {
  try {
    if (interaction.isButton()) {
      if (interaction.customId === 'pyrr_ticket_open') {
        if (!interaction.guild) return interaction.reply({ content: 'Server only.', ephemeral: true });
        const existing = interaction.guild.channels.cache.find(c => c.name === `ticket-${interaction.user.id}`);
        if (existing) return interaction.reply({ content: `You already have a ticket: ${existing}`, ephemeral: true });
        const overwrites = [
          { id: interaction.guild.roles.everyone.id, deny: [PermissionsBitField.Flags.ViewChannel] },
          { id: interaction.user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ReadMessageHistory] },
          { id: client.user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ManageChannels, PermissionsBitField.Flags.ReadMessageHistory] }
        ];
        const ch = await interaction.guild.channels.create({ name: `ticket-${interaction.user.id}`, type: ChannelType.GuildText, permissionOverwrites: overwrites, reason: `Ticket opened by ${interaction.user.tag}` });
        await ch.send({ content: `<@${interaction.user.id}>`, embeds: [embed('Support Ticket', 'Describe your issue here. Staff can close this ticket with the ticket close command.')], allowedMentions: { users: [interaction.user.id] } });
        return interaction.reply({ content: `Your ticket has been created: ${ch}`, ephemeral: true });
      }
    }
    if (!interaction.isChatInputCommand()) return;
    const cmd = commandMap.get(interaction.commandName);
    if (!cmd) return interaction.reply({ content: 'Command not found. Try the prefix help command.', ephemeral: true });
    const args = [];
    const input = interaction.options.getString('input');
    const target = interaction.options.getUser('target');
    if (target) args.push(target.id);
    if (input) args.push(...input.split(/\s+/));
    const ctx = ctxForInteraction(interaction, args);
    if (cmd.admin && !interaction.memberPermissions?.has(PermissionsBitField.Flags.Administrator)) return ctx.reply({ embeds: [fail('Administrator permission required.')] });
    if (cmd.mod && !interaction.memberPermissions?.has(PermissionsBitField.Flags.ModerateMembers) && !interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageMessages) && !interaction.memberPermissions?.has(PermissionsBitField.Flags.Administrator)) return ctx.reply({ embeds: [fail('Moderation permissions required.')] });
    await cmd.run(ctx);
  } catch (error) {
    console.error('[PYRR] Interaction error:', error);
    if (interaction.isRepliable() && !interaction.replied && !interaction.deferred) await interaction.reply({ content: 'The command failed. Check permissions and try again.', ephemeral: true }).catch(() => {});
  }
});

// ---------- SLASH COMMAND REGISTRATION (max 80 commands) ----------
async function registerSlashCommands() {
  if (!TOKEN || !CLIENT_ID) { console.warn('[PYRR] DISCORD_TOKEN or CLIENT_ID missing; skipping slash registration.'); return; }
  const defs = [];
  for (const name of slashCandidates) {
    const c = commandMap.get(name); if (!c) continue;
    const b = new SlashCommandBuilder().setName(c.name).setDescription(String(c.description).slice(0, 100));
    // Generic arguments keep slash commands consistent with prefix usage.
    b.addStringOption(o => o.setName('input').setDescription('Optional command input').setRequired(false));
    b.addUserOption(o => o.setName('target').setDescription('Optional target member').setRequired(false));
    defs.push(b.toJSON());
  }
  if (defs.length > 100) throw new Error('Slash command count exceeds Discord limit.');
  try {
    const rest = new REST({ version: '10' }).setToken(TOKEN);
    await rest.put(Routes.applicationCommands(CLIENT_ID), { body: defs });
    console.log(`[PYRR] Registered ${defs.length} slash commands.`);
  } catch (e) { console.error('[PYRR] Slash registration failed:', e.message); }
}

client.once('ready', async () => {
  console.log('==================================================');
  console.log(`${BOT_NAME} is online as ${client.user.tag}`);
  console.log(`Creator: ${CREATOR}`);
  console.log(`Servers: ${client.guilds.cache.size}`);
  console.log(`Unique commands: ${commandMap.size}`);
  console.log(`Prefix: ${PREFIX}`);
  console.log('==================================================');
  client.user.setPresence({ activities: [{ name: 'Noctis Official on Twitch', type: ActivityType.Streaming, url: TWITCH_URL }], status: 'online' });
  await registerSlashCommands();
});
client.on('error', e => console.error('[PYRR] Client error:', e));
process.on('unhandledRejection', e => console.error('[PYRR] Unhandled rejection:', e));
process.on('uncaughtException', e => { console.error('[PYRR] Uncaught exception:', e); });

if (!TOKEN) {
  console.error('[PYRR] Missing DISCORD_TOKEN environment variable. Add it in your hosting panel; never paste it into this file.');
} else {
  client.login(TOKEN).catch(e => { console.error('[PYRR] Login failed:', e.message); process.exitCode = 1; });
}
