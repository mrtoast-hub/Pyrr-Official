PYRR OFFICIAL — setup notes

Requirements:
- Node.js 22 or newer
- discord.js v14

Files:
- index.js: main bot code
- package.json: dependency and start command
- .env.example: variable names only; it contains no real token

Host setup:
1. Upload/extract this ZIP into your bot project.
2. Set DISCORD_TOKEN, CLIENT_ID, and BOT_OWNER_ID in the hosting panel's environment variables.
3. Enable these privileged intents in Discord Developer Portal if the bot needs them:
   - Server Members Intent
   - Message Content Intent
4. Invite the bot with the needed permissions for the features you plan to use.
5. Run: npm install
6. Run: npm start

Prefix: P' (example: P'help)
Slash commands are registered on startup when DISCORD_TOKEN and CLIENT_ID are set.

Notes:
- Commands require the corresponding Discord permissions and bot role hierarchy.
- Anti-nuke/anti-raid features in this build are alert-oriented; they do not automatically ban users.
- Reminder timers run only while the process stays online.
- Keep real tokens out of source files and GitHub.
